﻿using System;

class MethodDemo
{
    static void doit()
    {
        Console.WriteLine("Hello");
    }
    public static void Main()
    {
        doit();
        doit();
    }
}
