﻿using System;

class Assignment
{
    static void Main()
    {
        int first, second, third;
        first = 1;
        second = 2;
        third = second + first;
        Console.WriteLine(first);
        Console.WriteLine(second);
        Console.WriteLine(third);
    }
}

