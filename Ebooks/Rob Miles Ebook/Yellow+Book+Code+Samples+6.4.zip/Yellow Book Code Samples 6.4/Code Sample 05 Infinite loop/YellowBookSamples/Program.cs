﻿using System;

class Forever
{
    public static void Main()
    {
        do
            Console.WriteLine("Hello mum");
        while (true);
    }
}




