namespace TreehouseDefense
{
    class Invader
    {

    }
}