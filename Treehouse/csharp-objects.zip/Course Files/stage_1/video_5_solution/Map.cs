namespace TreehouseDefense
{
    class Map
    {
        public int Width;
        public int Height;
    }
}