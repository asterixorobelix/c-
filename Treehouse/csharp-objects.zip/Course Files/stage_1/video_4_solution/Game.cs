namespace TreehouseDefense
{
    class Game
    {
        public static void Main()
        {
            Tower tower = new Tower();
        }
    }
}