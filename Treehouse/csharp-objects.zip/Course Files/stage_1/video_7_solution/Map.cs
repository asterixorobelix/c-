namespace TreehouseDefense
{
    class Map
    {
        public readonly int Width;
        public readonly int Height;
        
        public Map(int width, int height)
        {
            Width = width;
            Height = height;
        }
    }
}