namespace TreehouseDefense
{
    class Invader
    {
        public MapLocation Location { get; private set; }
    }
}