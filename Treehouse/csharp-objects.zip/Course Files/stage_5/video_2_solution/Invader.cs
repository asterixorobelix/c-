namespace TreehouseDefense
{
    class Invader
    {
        private MapLocation _location;
        
        public MapLocation Location
        {
            get
            {
                return _location;
            }
            set
            {
                _location = value;
            }
        }
    }
}