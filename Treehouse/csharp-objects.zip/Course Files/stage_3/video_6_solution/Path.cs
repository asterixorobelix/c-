namespace TreehouseDefense
{
    class Path
    {
        
    }
}