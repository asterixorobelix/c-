namespace TreehouseDefense
{
    class MapLocation : Point
    {
        public MapLocation(int x, int y) : base(x, y)
        {
            
        }
    }
}