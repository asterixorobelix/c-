﻿namespace VideoOnDemand.Models.DTOModels
{
    public class InstructorDTO
    {
        public string InstructorName { get; set; }
        public string InstructorDescription { get; set; }
        public string InstructorAvatar { get; set; }
    }
}
