﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;

namespace AspNetCoreVideo.Entities
{
    public class User : IdentityUser
    {
    }
}
