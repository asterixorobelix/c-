﻿namespace AspNetCoreVideo.Models
{
    public enum Genres
    {
        None,
        Horror,
        Comedy,
        Romance,
        Action
    }
}
