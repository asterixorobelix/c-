﻿namespace AspNetCoreVideo.Services
{
    public interface IMessageService
    {
        string GetMessage();
    }
}
